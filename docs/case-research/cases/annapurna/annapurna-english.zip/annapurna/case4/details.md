# Case 4

**विषय:** जग्गा

**मुद्दा:** ललिता निवास

**साल:** 2075

**नोक्सानी:** १४३ रोपनी ६ आना

**मुख्य अभियुक्त:** माधवकु‌मार नेपाल र बाबुराम भट्टराई

**जोडिएका व्यक्ति:** विजयक्ष्मार गच्छदार, मीनकुमार गरुङ आदि

Lalita Niwas land grab scam or Lalita Niwas land scam (Nepali: ललिता निवास प्रकरण) is a scam where the land ownership of government owned Lalita Niwas which houses the Official Residence of the Prime Minister of Nepal, central office of the Nepal Rastra Bank and other VIP residences, was illegally transferred by land brokers to big business groups of Nepal through collusion with land revenue officials, ministers, political leaders and secretaries at various ministries of Nepal. The land involved in the land grab scam was 114 ropanis which amounted to billions of Nepalese rupees.


https://thehimalayantimes.com/nepal/300-accused-face-charges-in-lalita-niwas-land-grab-scam


