# Case 87

**विषय:** ३३ किलो सुन

**मुद्दा:** तस्करी

**साल:** 2074

**नोक्सानी:** करोडौ

**मुख्य अभियुक्त:** चूडामणि उप्रेती

**जोडिएका व्यक्ति:** वहालवाला प्रहरी अधिकारीसहित ७७ जना

Major gold smuggling operations ran through airports and border points with protection from customs officials and political networks.
